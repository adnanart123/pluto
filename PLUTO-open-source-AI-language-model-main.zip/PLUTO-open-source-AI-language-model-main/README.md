You can help us to create AI models trained with a millions of data on the internet today.
we want you with us to build the future.
you can contact us on the mail (adnan1324coder123@gmail.com)
you want to work honestly contact us on instagram to learn more [https://instagram.com/](https://www.instagram.com/_.nak_industries._/)
we want a team of people to design and make our open source AI model's dream come true 
we are doing this for the poor people on countries like nigeria and south africa the can't afford some AI but they want it bcause 
we are doing this
